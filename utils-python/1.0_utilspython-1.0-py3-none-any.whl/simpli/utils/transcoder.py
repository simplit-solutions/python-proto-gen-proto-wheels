#
# *******************************************************
# * Copyright (C) 2020 Simpli Route
# *
# * This file is part of Apollo.
# *
# * Apollo can not be copied and/or distributed without the express
# * permission of Simpli Route
# *****************************************************
#
from exception.collection_name_not_found_exception import (
    CollectionNameNotFoundException
)
from google.protobuf.descriptor import FieldDescriptor

import google.protobuf.struct_pb2 as struct_pb2
import simpli.proto.rdbms.commons.persistence.models_pb2 as models_pb2


table = 'table_name'
db_mapper = 'db_mapper'


def transcode(msg, record_id=None):
    """
    Transcode a proto msg into a DataUpsertRequest.
    :param record_id: optional id given to the persisted record.
    :param msg: msg to be converted.
    :return: a DataUpsertRequest.
    """
    table_name = get_collection_name(msg)
    struct = _get_fields_map(msg)
    annotation_map = _get_annotation_map(msg)
    if record_id is None:
        request = models_pb2.DataUpsertRequest(
            collection=table_name,
            data=struct,
            annotation=annotation_map
        )
    else:
        request = models_pb2.DataUpsertRequest(
            collection=table_name,
            id=record_id,
            data=struct,
            annotation=annotation_map
        )
    return request


def get_collection_name(msg):
    """
    Inspect a message and extract the collection name.
    :param msg: msg to extract the collection name from.
    :return: a collection name
    """
    table_name = None
    descriptor_map = msg.DESCRIPTOR.GetOptions().ListFields()

    for key, value in descriptor_map:
        if key.name == table:
            table_name = value

    if table_name is None:
        raise CollectionNameNotFoundException
    return table_name


def _get_fields_map(msg):
    """
    Inspect a message and extract a Struct.
    :param msg: msg to extract the fields map from.
    :return: a Struct mapping the properties.
    """
    field_descriptors = msg.DESCRIPTOR.fields
    dict_struct = dict()
    for field_entry in field_descriptors:
        field_type = field_entry.type
        value = getattr(msg, field_entry.name)
        if field_type == FieldDescriptor.TYPE_ENUM:
            enum_descriptor = field_entry.enum_type.values_by_number
            dict_struct[field_entry.name] = enum_descriptor[value].name
        elif field_type == FieldDescriptor.TYPE_MESSAGE:
            dict_struct[field_entry.name] = _get_fields_map(value)
        else:
            dict_struct[field_entry.name] = value
    struct = struct_pb2.Struct()
    struct.update(dict_struct)
    return struct


def _get_annotation_map(msg):
    """
    Extracts the annotations from the proto into a map
    :param msg: msg to be examined.
    :return: a map os field -> annotation
    """
    annotation_map = dict()
    field_descriptors = msg.DESCRIPTOR.fields
    for field_entry in field_descriptors:
        descriptor_map = field_entry.GetOptions().ListFields()
        for key, value in descriptor_map:
            if key.name == db_mapper:
                annotation_map[field_entry.name] = value
    return annotation_map
