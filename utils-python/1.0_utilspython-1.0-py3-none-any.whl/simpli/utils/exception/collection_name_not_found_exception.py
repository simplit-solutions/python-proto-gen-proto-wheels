#
# *******************************************************
# * Copyright (C) 2020 Simpli Route
# *
# * This file is part of Apollo.
# *
# * Apollo can not be copied and/or distributed without the express
# * permission of Simpli Route
# *****************************************************
#


class CollectionNameNotFoundException(Exception):
    pass
